<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Restoran FastFood | SMK WIKRAMA </title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
    <div class="judul">
    <h1 class="jdl">Restoran Fast Food</h1>
    <div class="atas">
    <a href="kelola.php">Kelola User</a>
    <a href="menu.php">Form Menu</a>
    <a href="kategori.php">Form Kategori</a>
    <a href="laporan.php">Laporan</a>
    </div>
    <div class="selamat">
        <h1>Selamat Datang Admin, Jamaludin</h1>
        <p>"Bekerjalah dengan hati yang ikhlas"</p>
        <p>Rumah Makan FAST FOOD</p>
    </div>
    </div>
    
    
</body>
</html>