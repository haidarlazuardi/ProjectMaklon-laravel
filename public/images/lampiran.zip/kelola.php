 <?php 
 include "koneksi.php";

 if(isset($_GET['hapus'])){
    $hapus="DELETE FROM tb_user WHERE kd_user='$_GET[id]'";
    $hoho=mysqli_query($conn,$hapus);
    if($hoho){
        echo "<script>alert('Data Terhapus');</script>";
        echo "<script>document.location.href='kelola.php';</script>";
    }
}

if(isset($_POST['simpan'])){

    $sim="insert into tb_user values('','$_POST[nama]','$_POST[no_hp]','$_POST[username]', '$_POST[password]','$_POST[level]')";
    $pan=mysqli_query($conn, $sim);
    if($pan){
    echo "<script>alert('Data Tersimpan')</script>";
    echo "<script>document.location.href='kelola.php';</script>";
    }
}

if(isset($_GET['edit'])){
    $am="select * from tb_user where kd_user='$_GET[id]'";
    $bil=mysqli_query($conn,$am);
    $ambil=mysqli_fetch_array($bil);
}

if(isset($_POST['update'])){
    $up = "UPDATE tb_user SET nama = '$_POST[nama]', no_hp = '$_POST[no_hp]', username = '$_POST[username]', password = '$_POST[password]', level = '$_POST[level]' WHERE kd_user='$_GET[id]'";
    $date = mysqli_query($conn, $up);
    if($date){
        echo "<script>alert('Data berhasil di update!');document.location.href='kelola.php'</script>";
    }else{
        echo "<script>alert('Data gagal di update!');document.location.href='kelola.php'</script>";
    }
}

 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form Kelola User</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <form action="" method="post">
    <div class="judul">
    <h2>Form Kelola User</h2>
    <ul>
        <li><a href="index.php" style="float:left; margin-left:90%">Kembali</a></li>
    </ul>
    </div>
    <div class="j">
        <div class="bagi"> 
    <table>
        
        <tr>
            <td><label for="">Nama</label></td>
            <td>:</td>
            <td><input type="text" name="nama" value="<?php echo @$ambil['nama']?> "></td>
        </tr>
        <tr>
            <td><label for="">No HP</label></td>
            <td>:</td>
            <td><input type="text" name="no_hp" value="<?= @$ambil['no_hp']?>"></td>
            
        </tr>
        <tr>
            <td><label for="">Username</label></td>
            <td>:</td>
            <td><input type="text" name="username"  value="<?= @$ambil['username']?>"></td>
        </tr>
        <tr>
            <td><label for="">Password</label></td>
            <td>:</td>
            <td><input type="text" name="password" value="<?= @$ambil['password']?>"></td>
        </tr>
        <tr>
            <td><label for="">Level</label></td>
            <td>:</td>
            <td><select name="level" value="<?= @$ambil['level']?>">
                <option value="kasir">Kasir</option>
                <option value="admin">Admin</option>
            </select></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
            <?php if(isset($_GET['edit'])){?>
            <input type="submit" value="update" name="update" ></td>
            <?php }else{ ?>
            <input type="submit" value="simpan" name="simpan">
            <?php } ?>
        </tr>
    </table>
    </div>

    <div class="bagi">
        <tr>
            <th><input type="text" name="tcari" value="<?= @$_POST['tcari'];?>"></td>
            <td><input type="submit" name=cari value="cari"></td>
            
        </tr>
        <br>
            <br>
        <table border=1 cellpadding="10" cellspacing="0">
        <tr>
            <td>Nama</td>
            <td>No.HP</td>
            <td>username</td>
            <td>Password</td>
            <td>Level</td>
            <td>Aksi</td>
        </tr>
            <?php 
            $sql="SELECT * FROM tb_user ";
            if(isset($_POST['cari'])){
                $sql = "SELECT * FROM tb_user WHERE nama  LIKE '%$_POST[tcari]%'";
            }else{
                $sql = "SELECT * FROM tb_user";
            }
            $query= mysqli_query($conn, $sql);
            while ($row=mysqli_fetch_assoc($query)) {
                # code...
            
            ?>
            <tr>
                <td><?= $row["nama"]; ?></td>
                <td><?= $row["no_hp"] ?></td>
                <td><?= $row["username"] ?></td>
                <td><?= $row["password"] ?></td>
                <td><?= $row["level"] ?></td>
                <td><a href="kelola.php?edit&id=<?= $row['kd_user'];?>">EDIT</a>|
                <a href="kelola.php?hapus&id=<?= $row['kd_user'];?>"onclick= "return confirm('waw?')">HAPUS</a></td>
            </tr>

            <?php } ?>
        </table>
    </div>
    </div>
    </form>
</body>
</html>