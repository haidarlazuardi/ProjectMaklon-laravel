<?php 
session_start();

include 'koneksi.php';

@$username = $_POST["username"];
@$password = $_POST["password"];

if(isset($_POST['login'])){
$level = "admin";
$level2="kasir";
$sql = mysqli_query($conn,"SELECT * FROM tb_user WHERE username='$username' AND password='$password'");

$cek = mysqli_num_rows($sql);

$row = mysqli_fetch_array($sql);
if($cek > 0 && $row[5]==$level  ){
    header("Location: index.php");
    exit;
}elseif($cek > 0 && $row[5] == $level2){
    header("Location: transaksi.php");
    exit;
}else{
    echo"<script>alert('Username dan Password Salah')</script>";

}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
    <form action="" method="post">
        <div class="loginbox" align="center"; >
                <h2>Login</h2>
                <p>
                    <label for="">Username</label>
                    <input type="text" name="username" autofocus placeholder="Masukan username">
                </p>
                <p>
                    <label for="">Password</label>
                    <input type="password" name="password" autofocus placeholder="Masukan Password">
                </p>
                    <input type="submit" value="Login" name="login">
                
            
        </div>
    </form>
</body>
</html>