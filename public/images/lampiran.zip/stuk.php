<?php
	session_start();

	require 'koneksi.php';

	if(isset($_POST['selesai'])){
            echo "<script>alert('selesai belanja');document.location.href='transaksi.php';</script>";

	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Struk</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<br><br><br>

	<div class="">
		<div class="card" >
		  <div class="container" style="background-color:white; width:500px; height:500px" >
          <br>
		  	<h2 style="margin-left:170px">Struk Belanja</h2>
              <p style="margin-left:160px">Rumah Makan Fast Food</p>
		  		<table border="0" style="margin-left:100px;">
                  <br><br>
		  			<tr>
		  				<th>Menu</th>
		  				<th>Harga</th>
		  				<th>Jumlah</th>
		  				<th>Subtotal</th>
		  				<th>Tanggal</th>
		  			</tr>
		  			 <?php

                        $sql = "SELECT * FROM query_struk";
						$query = mysqli_query($conn, $sql);
                        while($row = mysqli_fetch_assoc($query)):
                     ?>
		  			<tr>
		  				<td><?= $row['menu'] ?></td>
		  				<td><?= $row['harga'] ?></td>
		  				<td><?= $row['jumlah'] ?></td>
		  				<td><?= $row['subtotal'] ?></td>
		  				<td><?= $row['tgl_transaksi'] ?></td>
		  			</tr>
		  			<?php endwhile; ?>
		  		</table>
		  		<br>
			    <div style="margin-left:90px;">
				    <label>Total</label>
                    <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>
				    <input type="text" name="" value="<?= @$_SESSION['total'] ?>">
			    </div>
			    <div style="margin-left:90px;">
				    <label>Pembayaran</label>
                    <label>:</label>
				    <input type="text" name="" value="<?= @$_SESSION['membayar'] ?>">
			    </div>
			    <div style="margin-left:90px;">
				    <label>Kembali</label>
                    <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>
				    <input type="text" name="" value="<?= @$_SESSION['kembali'] ?>">
			    </div>
			    <br>
                <p style="margin-left:190px">---Terimaksih---</p>
			    <form method="post">
                <br><br>
				    <div>
				    		<input type="submit" name="selesai" value="Selesai" style="margin-left: 60px;"><br>
				    </div>
			    </form>
		  </div>
		</div>
	</div>
</body>
</html>
