<?php 
    include "koneksi.php";

    if(isset($_POST['simpan'])){
    $lokasi_file =$_FILES['foto']['tmp_nama'];
    $nama_file = $_FILES['foto']['nama'];
    $folder = "foto/$nama_file";
    
    $upload = move_uploaded_file($lokasi_file,"folder");
        $sim="insert into tb_menu values('','$_POST[menu]','$_POST[jenis]','$_POST[harga]', '$_POST[status]','$nama_file','$_POST[kategori]')";
        $pan=mysqli_query($conn, $sim);
        if($pan){
        echo "<script>alert('Data Tersimpan')</script>";
        echo "<script>document.location.href='menu.php';</script>";
        }
    }

    if(isset($_GET['edit'])){
        $am="SELECT * FROM tb_menu where kd_menu='$_GET[id]'";
        $bil=mysqli_query($conn,$am);
        $ambil=mysqli_fetch_assoc($bil);
    }

    if(isset($_POST['update'])){
        $up = "UPDATE tb_menu SET menu = '$_POST[menu]', jenis = '$_POST[jenis]', harga = '$_POST[harga]', status = '$_POST[status]', foto = '$_POST[foto]' WHERE kd_menu='$_GET[id]'";
        $date = mysqli_query($conn, $up);
        if($date){
            echo "<script>alert('Data berhasil di update!');document.location.href='menu.php'</script>";
        }else{
            echo "<script>alert('Data gagal di update!');document.location.href='menu.php'</script>";
        }
    }

    if(isset($_GET['hapus'])){
        $hapus="DELETE FROM tb_menu WHERE kd_menu='$_GET[id]'";
        $hoho=mysqli_query($conn,$hapus);
        if($hoho){
            echo "<script>alert('Data Terhapus');</script>";
            echo "<script>document.location.href='menu.php';</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form Kelola Menu</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<form action="" method="post">
    <div class="judul">
        <h2>Form Kelola Menu</h2>
        <ul>
        <li><a href="index.php" style="float:left; margin-left:90%">Kembali</a></li>
    </ul>
    </div>

    <div class="j">
        <div class="bagi2"> 
    <table>
        
        <tr>
            <td><label for="">Menu</label></td>
            <td>:</td>
            <td><input type="text" name="menu" value="<?= @$ambil['menu'] ?>" ></td>
        </tr>
        <tr>
            <td><label for="">Jenis</label></td>
            <td>:</td>
            <td>
                <select name="jenis" >
                <option value="makanan">Makanan</option>
                <option value="minuman">Minuman</option>
                </select>
            </td>
        </tr>
        <tr>
            <td><label for="">Harga</label></td>
            <td>:</td>
            <td><input type="text" name="harga" value="<?= @$ambil['harga'] ?>"></td>
        </tr>
        <tr>
            <td><label for="">status</label></td>
            <td>:</td>
            <td><input type="text" name="status" value="<?= @$ambil['status'] ?>"></td>
        </tr>
        <tr>
            <td><label for="">Foto</label></td>
            <td>:</td>
            <td><input type="file" name="foto" value="<?= @$ambil['foto'] ?>"></td>
        </tr>
        <tr>
            <td><label for="">Kategori</label></td>
            <td>:</td>
            <td><select>
            <?php 
            $query=mysqli_query($conn, "SELECT * FROM tb_kategori");
            while ($a=mysqli_fetch_assoc($query)) {
            ?>
                <option value="<?php echo $a['kd_kategori'] ?>"><?php echo $a['kategori'] ?></option>
            <?php } ?>
            </select></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
            <?php if(isset($_GET['edit'])){?>
            <input type="submit" value="update" name="update" ></td>
            <?php }else{ ?>
            <input type="submit" value="simpan" name="simpan">
            <?php } ?>
        </tr>
    </table>
    </div>
    
    <div class="bagi">
        <tr>
            <th><input type="text" name="tcari" value="<?=@$_POST['tcari'];?>"></td>
            <td><input type="submit" name=cari value="cari"></td>
            
        </tr>
        <br>
            <br>
        <table border=1 cellpadding="10" cellspacing="0">
        <tr>
            <td>Menu</td>
            <td>Jenis</td>
            <td>Harga</td>
            <td>Status</td>
            <td>Foto</td>
            <td>ketegori</td>
            <td>Aksi</td>
        </tr>
        <?php 
            $sql="SELECT * FROM tb_menu ";
            if(isset($_POST['cari'])){
                $sql = "SELECT * FROM tb_menu WHERE menu  LIKE '%$_POST[tcari]%'";
            }else{
                $sql = "SELECT * FROM tb_menu";
            }
            $query= mysqli_query($conn, $sql);
            while ($row=mysqli_fetch_assoc($query)) {
                # code...
            
            ?>
            <tr>
                <td><?= $row["menu"]; ?></td>
                <td><?= $row["jenis"] ?></td>
                <td><?= $row["harga"] ?></td>
                <td><?= $row["status"] ?></td>
                <td><img src="foto/<?= $row['foto']; ?>" style="width=50%;" alt=""></td>
                <td><?= $row['kd_kategori']?></td>
                <td><a href="menu.php?edit&id=<?= $row['kd_menu'];?>">EDIT</a>|
                <a href="menu.php?hapus&id=<?= $row['kd_menu'];?>"onclick= "return confirm('waw?')">HAPUS</a></td>
            </tr>

            <?php } ?>
            
        </table>
    </div>
    </div>
    </form>
</body>
</html>