<?php 
include "koneksi.php";

if(isset($_POST['simpan'])){
    //ambil data dari formulir
    $nama = $_POST['nama'];
    $no_hp = $_POST['no_hp'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $level =$_POST['level'];

     //buat Query
$sql = "INSERT INTO tb_user VALUES 
     ('$nama','$no_hp','$username','$password','$level')";
$query = mysqli_query($conn, $sql);

if(query){
    header('Location: index.php?status=sukses');
}else{
    header('Location: index.php?status=gagal');
}
}else{
die("Akses dilarang...");
}
?>