-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2019 at 03:56 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restoran`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `query_laporan`
-- (See below for the actual view)
--
CREATE TABLE `query_laporan` (
`menu` varchar(100)
,`harga` int(11)
,`jumlah` int(11)
,`subtotal` int(11)
,`tgl_transaksi` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `query_struk`
-- (See below for the actual view)
--
CREATE TABLE `query_struk` (
`no_meja` int(11)
,`menu` varchar(100)
,`harga` int(11)
,`jumlah` int(11)
,`subtotal` int(11)
,`tgl_transaksi` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `kd_kategori` int(11) NOT NULL,
  `kategori` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`kd_kategori`, `kategori`) VALUES
(2, 'Makanan '),
(3, 'Makanan ringan');

-- --------------------------------------------------------

--
-- Table structure for table `tb_menu`
--

CREATE TABLE `tb_menu` (
  `kd_menu` int(11) NOT NULL,
  `menu` varchar(100) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(15) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `kd_kategori` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_menu`
--

INSERT INTO `tb_menu` (`kd_menu`, `menu`, `jenis`, `harga`, `status`, `foto`, `kd_kategori`) VALUES
(1, 'jengkol', 'makanan', 1000, 'ada', '', 0),
(2, 'Re', 'makanan', 100000, 'AMAN', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `kd_transaksi` int(11) NOT NULL,
  `kd_menu` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `kd_user` int(11) NOT NULL,
  `no_meja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`kd_transaksi`, `kd_menu`, `jumlah`, `harga`, `subtotal`, `tgl_transaksi`, `kd_user`, `no_meja`) VALUES
(1, 1, 1000, 78, 78000, '2019-01-17 00:00:00', 0, 2),
(2, 0, 1000, 78, 78000, '2019-01-17 00:00:00', 0, 2),
(3, 1, 1000, 78, 78000, '2019-01-17 00:00:00', 0, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `kd_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`kd_user`, `nama`, `no_hp`, `username`, `password`, `level`) VALUES
(3, 'Evilia Faujiah', '089677674565', 'kasir', '321', 'kasir'),
(5, 'Jamaludin', '085697319458', 'admin', '123', 'admin'),
(6, ' ', '', '', '', 'kasir');

-- --------------------------------------------------------

--
-- Structure for view `query_laporan`
--
DROP TABLE IF EXISTS `query_laporan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `query_laporan`  AS  select `tb_menu`.`menu` AS `menu`,`tb_transaksi`.`harga` AS `harga`,`tb_transaksi`.`jumlah` AS `jumlah`,`tb_transaksi`.`subtotal` AS `subtotal`,`tb_transaksi`.`tgl_transaksi` AS `tgl_transaksi` from (`tb_transaksi` join `tb_menu`) where (`tb_transaksi`.`kd_menu` = `tb_menu`.`kd_menu`) ;

-- --------------------------------------------------------

--
-- Structure for view `query_struk`
--
DROP TABLE IF EXISTS `query_struk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `query_struk`  AS  select `tb_transaksi`.`no_meja` AS `no_meja`,`tb_menu`.`menu` AS `menu`,`tb_transaksi`.`harga` AS `harga`,`tb_transaksi`.`jumlah` AS `jumlah`,`tb_transaksi`.`subtotal` AS `subtotal`,`tb_transaksi`.`tgl_transaksi` AS `tgl_transaksi` from (`tb_menu` join `tb_transaksi`) where (`tb_transaksi`.`kd_menu` = `tb_menu`.`kd_menu`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`kd_kategori`);

--
-- Indexes for table `tb_menu`
--
ALTER TABLE `tb_menu`
  ADD PRIMARY KEY (`kd_menu`),
  ADD KEY `kd_kategori` (`kd_kategori`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`kd_transaksi`),
  ADD KEY `kd_user` (`kd_user`),
  ADD KEY `kd_menu` (`kd_menu`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`kd_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `kd_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_menu`
--
ALTER TABLE `tb_menu`
  MODIFY `kd_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `kd_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
