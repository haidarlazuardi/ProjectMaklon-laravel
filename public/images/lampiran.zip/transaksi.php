    <?php 
    include "koneksi.php";
    session_start();

    if(isset($_GET['edit'])){
        $am="SELECT * FROM tb_transaksi WHERE kd_transaksi='$_GET[id]'";
        $bil=mysqli_query($conn,$am);
        $ambil=mysqli_fetch_array($bil);
    }

    if(isset($_GET['hapus'])){
        $hapus="DELETE FROM tb_transaksi WHERE kd_transaksi='$_GET[id]'";
        $hoho=mysqli_query($conn,$hapus);
        if($hoho){
            echo "<script>alert('Data Terhapus');</script>";
            echo "<script>document.location.href='transaksi.php';</script>";
        }
    }

    if(isset($_POST['simpan'])){
        $tanggal = date('Y-m-d');
        $subtotal = $_POST['harga'] * $_POST['jumlah'];
        $sim="insert into tb_transaksi values('$_POST[no]','$_POST[menu]','$_POST[harga]', '$_POST[jumlah]', '$subtotal','$tanggal','','$_POST[meja]')";
        //var_dump($sim);
        //die();
        $pan=mysqli_query($conn, $sim);
        
        
        if($pan){
        echo "<script>alert('Data Tersimpan')</script>";
        echo "<script>document.location.href='transaksi.php';</script>";
        }
    }
    if (isset($_POST['bayar'])) {
        $membayar = $_POST['membayar'];
        $total = $_POST['total'];
        $_SESSION['total'] = $total;
        $_SESSION['membayar'] = $membayar;
        $kembali = $membayar - $total; 
        
        $_SESSION['kembali'] = $kembali;
        echo "<script>document.location.href='stuk.php'</script>";
        // var_dump($_POST);
        // die();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FORM TRANSAKSI</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<form action="" method="post">
    <div class="judul">
    <h2>Form Transaksi</h2>
    <ul>
        <li><a href="login.php" style="float:left; margin-left:90%">Logout</a></li>
    </ul>
    </div>

    <div class="j">
        <div class="bagi"> 
    <table>
        
        <tr>
            <td><label for="">No Transaksi</label></td>
            <td>:</td>
            <td><input type="text" name="no" value="<?= @$ambil['kd_transaksi'] ?>"></td>
        </tr>
        <tr>
            <td><label for="">Menu</label></td>
            <td>:</td>
            <td>
                <select name="menu">
                <?php 
                $query=mysqli_query($conn,"SELECT * FROM tb_menu");
                while ($a=mysqli_fetch_assoc($query)) {
                    ?>
                
                
                    <option value="<?= $a['kd_menu']?>"><?= $a['menu']?></option>
                <?php } ?>
                </select>
            </td>
        </tr>
        <tr>
            <td><label for="">Harga</label></td>
            <td>:</td>
            <td><input type="text" name= "harga" value="<?= @$ambil['harga'] ?>"></td>
        </tr>
        <tr>
            <td><label for="">Jumlah</label></td>
            <td>:</td>
            <td><input type="text" name= "jumlah" value="<?= @$ambil['jumlah'] ?>"></td>
        </tr>
        <tr>
            <td><label for="">No Meja</label></td>
            <td>:</td>
            <td><select name="meja">
            <?php 
            for($i=1; $i<=100;$i++){
                ?>
            
                <option><?php echo $i ?></option>
            <?php } ?>
            
            </select></td>
        </tr>
        
        <tr>
            <td></td>
            <td></td>
            <td>
            <?php if(isset($_GET['edit'])){?>
            <input type="submit" value="update" name="update" ></td>
            <?php }else{ ?>
            <input type="submit" value="simpan" name="simpan">
            <?php } ?>
            </td>
        </tr>
    </table>
    </div>

    <div class="bagi">
        <tr>
            <td><input type="text" name="tcari" value="<?= @$_POST['tcari'];?>"></td>
            <td><input type="submit" name=cari value="cari"></td>
            
        </tr>
        <br>
            <br>
        <table border=1 cellpadding="10" cellspacing="0">
        <tr>
            <td>No Transaksi</td>
            <td>Menu</td>
            <td>Harga</td>
            <td>Jumlah</td>
            <td>Subtotal</td>
            <td>No Meja</td>
            <td>Aksi</td>
        </tr>
        <?php 
            $sql="SELECT * FROM tb_transaksi ";
            // if(isset($_POST['cari'])){
            //     $sql = "SELECT * FROM tb_transaksi WHERE menu  LIKE '%$_POST[tcari]%'";
            // }else{
                // $sql = "SELECT * FROM tb_transaksi";
            // }
            $query= mysqli_query($conn, $sql);
            while ($row=mysqli_fetch_assoc($query)) {
                # code...
            
            ?>

            <tr>
                <td><?= $row['kd_transaksi']; ?></td>
                <td><?= $row["kd_menu"] ?></td>
                <td><?= $row["harga"] ?></td>
                <td><?= $row["jumlah"] ?></td>
                <td>
                    <input type="text" name="total" value="<?= $row['subtotal'];?>">
                </td>
                <td><?= $row["no_meja"] ?></td>
                <td><a href="transaksi.php?edit&id=<?= $row['kd_transaksi'];?>">EDIT</a>|
                <a href="transaksi.php?hapus&id=<?= $row['kd_transaksi'];?>"onclick= "return confirm('waw?')">HAPUS</a></td>
            </tr>

            <?php } ?>

        
        </table>
        <br>
        
        <div>
                <tr>
                    <td><input type="submit" name="selesai" value="selesai" ></td>
                </tr>
        </div>
        <table>
        <br>
        <tr>
            <td><label for="">Total</label></td>
            <td></td>
            <td></label>
        
        
        <?php 
            $sql4 = "SELECT sum(subtotal) as subtotal FROM tb_transaksi";
            $query4 = mysqli_query($conn, $sql4);
            $ambil3 = mysqli_fetch_assoc($query4);
            $total = $ambil3['subtotal'];
        ?>
         <?php if(isset($_POST['selesai'])): ?>
            <input type="text" name="total" value="<?= $total; ?>" readonly>
        <?php elseif(isset($_POST['bayar'])): ?>
            <input type="text" name="total" value="<?= @$_SESSION['total'] ?>">
        <?php else: ?>
            <input type="text" name="total" value="">
        <?php endif; ?>
        </tr>
        <tr>
            <td><label>bayar</label></td>
            <td></td>
            <td><input type="text" name="membayar"></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><input type="submit" name="bayar" value="bayar"></td>
        </tr>
        <tr>
            <td><label for="">Kembali</label></td>
            <td></td>
            <td><input type="text" value="<?php echo @$kembali ?>" name="kembali"></td>
            </td>
        </tr>
        </table>
    </div>
    </div>
    </form>
</body>
</html>