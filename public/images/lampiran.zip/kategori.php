<?php 
    include "koneksi.php";

    if(isset($_POST['simpan'])){
        $sim="insert into tb_kategori values('','$_POST[kategori]')";
        $pan=mysqli_query($conn, $sim);
        if($pan){
        echo "<script>alert('Data Tersimpan')</script>";
        echo "<script>document.location.href='kategori.php';</script>";
        }
    }

    if(isset($_GET['edit'])){
        $am="SELECT * FROM tb_kategori WHERE kd_kategori='$_GET[id]'";
        $bil=mysqli_query($conn,$am);
        $ambil=mysqli_fetch_assoc($bil);

    }

    if(isset($_GET['hapus'])){
        $hapus="DELETE FROM tb_kategori WHERE kd_kategori='$_GET[id]'";
        $hoho=mysqli_query($conn,$hapus);
        if($hoho){
            echo "<script>alert('Data Terhapus');</script>";
            echo "<script>document.location.href='kategori.php';</script>";
        }
    }

    if(isset($_POST['update'])){
        $up= "UPDATE tb_kategori SET kategori='$_POST[kategori]' WHERE kd_kategori=$_GET[id]";
        $date= mysqli_query($conn,$up);
        if($date){
            echo "<script>alert('Data berhasil di update!');document.location.href='kategori.php'</script>";
        }else{
            echo"<script>alert('Data berhasil di update!');document.location.href='kategori.php'</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form Kategori</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <form action="" method="post">
    <nav>
        <div class="judul">
            <h2>Kelola Kategori</h2>
            <ul>
        <li><a href="index.php" style="float:left; margin-left:90%">Kembali</a></li>
    </ul>
        </div>
    </nav>
    <div class="j"> 
    <tr>
        <td><label for="">Kategori</label></td>
        <td>:</td>
        <td><input type="text" name="kategori" value="<?=@$ambil['kategori'] ?>"></td>
        <td>
            <?php if(isset($_GET['edit'])){?>
            <input type="submit" value="update" name="update" ></td>
            <?php }else{ ?>
            <input type="submit" value="simpan" name="simpan">
            <?php } ?>
    </tr>
    <br>
    <br>
   <table  border=1 cellpadding="10" cellspacing="0">
   <tr>
                
        <td>Kategori</td>
        <td>Aksi</td>
    </tr>
    <?php 
        $sql= "SELECT * FROM tb_kategori";
        $query= mysqli_query($conn,$sql);
        while ($row=mysqli_fetch_assoc($query)) {
            # code...
        
        ?>
        <tr>
            <td><?= @$row["kategori"]; ?></td>
            <td><a href="kategori.php?edit&id=<?= $row['kd_kategori'];?>">EDIT</a>|
            <a href="kategori.php?hapus&id=<?= $row['kd_kategori'];?>"onclick= "return confirm('waw?')">HAPUS</a></td>
        </tr>

        <?php } ?>
    </div>
   </table>
   </form>
</body>
</html>